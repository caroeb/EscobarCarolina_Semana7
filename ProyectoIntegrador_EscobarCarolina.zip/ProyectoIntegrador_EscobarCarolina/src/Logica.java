import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.TreeSet;

import processing.core.PApplet;

public class Logica {

	private PApplet app;
	private ArrayList alumnos = new ArrayList<Alumno>();
	private ArrayList copia = new ArrayList<Alumno>();
	private TreeSet ordenamiento = new TreeSet<Alumno>();
	private HashSet ordenamientoH = new HashSet<Alumno>();
	private int teclas = 0;

	public Logica(PApplet app) {

		this.app = app;
		String[] nombres, datos, colores;
		alumnos = new ArrayList<Alumno>();
		copia = new ArrayList<Alumno>();
		ordenamiento = new TreeSet<Alumno>(new Edad());
		ordenamientoH = new HashSet<Alumno>();

		nombres = app.loadStrings("data/nombres.txt");
		datos = app.loadStrings("data/datos.txt");
		colores = app.loadStrings("data/colores.txt");

		for (int i = 0; i < nombres.length; i++) {
			String[] nombre = nombres[i].split(":");
			String[] dato = datos[i].split("/");
			String[] color = colores[i].split("/");
			alumnos.add(new Alumno(nombre[0], nombre[1], Long.parseLong(dato[0]), Integer.parseInt(dato[1]),
					Integer.parseInt(dato[2]), Integer.parseInt(color[0]), Integer.parseInt(color[1]),
					Integer.parseInt(color[2])));

		}

		copia.addAll(alumnos);
	}

	public void pintar() {

		//
		Iterator<Alumno> it = ordenamientoH.iterator();
		int j = 0;
		while (it.hasNext()) {
			Alumno alu = it.next();
			alu.pintar(100, 20 + 10 * j);
			j++;
		}

		for (int i = 0; i < alumnos.size(); i++) {
			Alumno a = (Alumno) alumnos.get(i);
			a.pintar(100, 20 + 10 * i);

		}
	}

	public void teclas() {
		if (app.keyCode == '1') {
			alumnos.clear();
			ordenamiento.clear();
			ordenamientoH.clear();

			alumnos.addAll(copia);
			Collections.sort(alumnos);
		}
		if (app.keyCode == '2') {
			alumnos.clear();
			ordenamiento.clear();
			ordenamientoH.clear();

			alumnos.addAll(copia);
			Collections.sort(alumnos, new Peso());
		}
		if (app.keyCode == '3') {
			alumnos.clear();
			ordenamiento.clear();
			ordenamientoH.clear();

			ordenamiento.addAll(copia);
			alumnos.addAll(ordenamiento);
		}

		if (app.keyCode == '4') {
			alumnos.clear();
			ordenamiento.clear();
			ordenamientoH.clear();
			ordenamientoH.addAll(copia);
			alumnos.addAll(ordenamientoH);
		}

	}

}
