import processing.core.PApplet;

public class Alumno implements Comparable<Alumno>  {

	private PApplet app;
	private String nombre, apellido;
	private int  edad, peso, r, g, b, x, y;
	private float cedula;

	public Alumno(String nombre, String apellido, float cedula, int edad, int peso, int r, int g, int b) {
		super();
		this.app = app;
		this.nombre = nombre;
		this.apellido = apellido;
		this.cedula = cedula;
		this.edad = edad;
		this.peso = peso;
		this.r = r;
		this.g = g;
		this.b = b;
	}


	public void pintar(int x, int y) {
		//
		this.x=x;
		this.y=y;
		app.fill(r,g,b);
		app.text(nombre + " " + apellido + " " + cedula + " " + edad + " "+ peso + " " , x, y);
	}

	public String getNombre() {
		
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}



	public float getCedula() {
		return cedula;
	}


	public void setCedula(float cedula) {
		this.cedula = cedula;
	}


	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public int getPeso() {
		return peso;
	}

	public void setPeso(int peso) {
		this.peso = peso;
	}

	public int getR() {
		return r;
	}

	public void setR(int r) {
		this.r = r;
	}

	public int getG() {
		return g;
	}

	public void setG(int g) {
		this.g = g;
	}

	public int getB() {
		return b;
	}

	public void setB(int b) {
		this.b = b;
	}


	@Override
	public int compareTo(Alumno o) {
		return this.nombre.compareTo(o.getNombre());
	}

}
